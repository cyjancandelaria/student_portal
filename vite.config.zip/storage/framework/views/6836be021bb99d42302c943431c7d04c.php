<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 400px;
            margin: 80px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px #ccc;
        }

        h1 {
            text-align: center;
        }

        label {
            display: block;
            margin-top: 15px;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 10px;
            margin-top: 20px;
            background: #333;
            color: white;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background: #555;
        }

        .error {
            color: red;
            margin-top: 5px;
            font-size: 14px;
        }

        .success {
            background: #d4edda;
            color: #155724;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
        }

        .signup-link {
            text-align: center;
            margin-top: 15px;
        }

        .password-container {
            position: relative;
            width: 100%;
        }

        .password-container input {
            width: 100%;
            padding: 10px 65px 10px 10px;
            box-sizing: border-box;
        }

        .password-container button {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            width: auto;
            padding: 0;
            margin: 0;
            background: transparent;
            color: #555;
            border: none;
            cursor: pointer;
            font-size: 13px;
        }

        .password-container button:hover {
            background: transparent;
            color: #000;
        }
    </style>
</head>

<body>

<div class="container">

    <h1>Login</h1>

    <?php if(session('success')): ?>
        <div class="success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="error">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('login.submit')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <label>Username</label>
        <input
            type="text"
            name="username"
            value="<?php echo e(old('username')); ?>"
            required
        >

        <label>Password</label>
        <div class="password-container">
            <input type="password" name="password" id="loginPassword" placeholder="Password" required>
            <button type="button" onclick="togglePassword('loginPassword', this)">Show</button>
        </div>

        <button type="submit">Login</button>
    </form>

    <div class="signup-link">
        <p>Don't have an account?</p>
        <a href="<?php echo e(route('signup')); ?>">Sign Up</a>
    </div>

</div>

<script>
    function togglePassword(id, button) {
        const password = document.getElementById(id);

        if (password.type === "password") {
            password.type = "text";
            button.textContent = "Hide";
        } else {
            password.type = "password";
            button.textContent = "Show";
        }
    }
</script>

</body>
</html><?php /**PATH C:\xampp\htdocs\MIDTERM_LABORATORYEXAM_ABUAN_CALLEJO_CANDELARIA_GALZOTE_TRIA_UBOD_VILLANUEVA_ZARASATE-app\resources\views/dashboard_layout/login.blade.php ENDPATH**/ ?>