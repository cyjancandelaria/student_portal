<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 450px;
            margin: 40px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px #ccc;
        }

        h1 {
            text-align: center;
        }

        label {
            display: block;
            margin-top: 15px;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 10px;
            margin-top: 20px;
            background: #333;
            color: white;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background: #555;
        }

        .error {
            color: red;
            margin-bottom: 15px;
        }

        .login-link {
            text-align: center;
            margin-top: 15px;
        }
        .password-container {
            display: flex;
            align-items: center;
            width: 100%;
        }

        .password-container input {
            flex: 1;
        }

        .password-container button {
            cursor: pointer;
            border: none;
            background: transparent;
            font-size: 18px;
            margin-left: 5px;
        }
    </style>
</head>

<body>

<div class="container">

    <h1>Sign Up</h1>

    <?php if($errors->any()): ?>
        <div class="error">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('signup.submit')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <label>Full Name</label>
        <input
            type="text"
            name="fullname"
            value="<?php echo e(old('fullname')); ?>"
            required
        >

        <label>Address</label>
        <input
            type="text"
            name="address"
            value="<?php echo e(old('address')); ?>"
            required
        >

        <label>Age</label>
        <input
            type="number"
            name="age"
            value="<?php echo e(old('age')); ?>"
            min="1"
            max="100"
            required
        >

        <label>Username</label>
        <input
            type="text"
            name="username"
            value="<?php echo e(old('username')); ?>"
            required
        >

        <label>Password</label>
        <div class="password-container">
            <input type="password" name="password" id="loginPassword" placeholder="Password" required>

            <button type="button" onclick="togglePassword('loginPassword', this)">👁</button>
        </div>

        <button type="submit">Sign Up</button>
    </form>

    <div class="login-link">
        <p>Already have an account?</p>
        <a href="<?php echo e(route('login')); ?>">Login</a>
    </div>

</div>

<script>
    function togglePassword(id, button) {
        const password = document.getElementById(id);

        if (password.type === "password") {
            password.type = "text";
            button.textContent = "🙈";
        } else {
            password.type = "password";
            button.textContent = "👁";
        }
    }
</script>

</body>
</html><?php /**PATH C:\xampp\htdocs\MIDTERM_LABORATORYEXAM_ABUAN_CALLEJO_CANDELARIA_GALZOTE_TRIA_UBOD_VILLANUEVA_ZARASATE-app\resources\views/dashboard_layout/sign_up.blade.php ENDPATH**/ ?>